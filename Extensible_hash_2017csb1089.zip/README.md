#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Feb 20 21:16:34 2021

@author: yashaswi
"""

# Extensible Hashing

* instructions to run
    To run extensible hashing with Garbage collection :
    ** python3 ext_hash.py
    ** you will be prompted to enter values of size of ssm, size of record bucket, size of directory bucket, limit of main memory
    
    To run extensible hashing without Garbage collection :
    ** python3 ext_hash_gb.py
    ** you will be prompted to enter values of size of ssm, size of record bucket, size of directory bucket, limit of main memory
    
    To generate dataset :
    ** python3 synth_data.py 
    ** you will be asked the size of the dataset.
    
    
